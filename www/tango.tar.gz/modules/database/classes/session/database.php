<?php defined('SYSPATH') or die('No direct script access.');

class Session_Database extends Kohana_Session_Database {}
