<?php defined('SYSPATH') or die('No direct access allowed.');

class Fire extends Fire_Helper {}

