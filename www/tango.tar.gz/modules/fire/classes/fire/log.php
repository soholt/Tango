<?php defined('SYSPATH') or die('No direct script access.');
/**
 * File log writer. Add this class to your app to override.
 * 
 * Originally forked from github.com/pedrosland/kohana-firephp
 * [!!] This is a complete rewrite
 * 
 * @package		Fire
 * @author		Kemal Delalic <github.com/kemo>
 * @author		Mathew Davies <github.com/ThePixelDeveloper>
 * @version		1.0.0.
 */
class Fire_Log extends Fire_Log_Writer {}
