<?php defined('SYSPATH') or die('No direct script access.');

class Form extends Kohana_Form {}
