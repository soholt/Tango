<?php defined('SYSPATH') or die('No direct script access.');

class Fragment extends Kohana_Fragment {}
