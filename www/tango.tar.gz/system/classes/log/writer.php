<?php defined('SYSPATH') or die('No direct script access.');

abstract class Log_Writer extends Kohana_Log_Writer {}
