<?php defined('SYSPATH') or die('No direct script access.');

class Kohana_HTTP_Exception_411 extends HTTP_Exception {

	/**
	 * @var   integer    HTTP 411 Length Required
	 */
	protected $_code = 411;

}