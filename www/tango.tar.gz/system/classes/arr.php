<?php defined('SYSPATH') or die('No direct script access.');

class Arr extends Kohana_Arr {}