<?php defined('SYSPATH') or die('No direct script access.');

class Debug extends Kohana_Debug {}
