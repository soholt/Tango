<?php defined('SYSPATH') or die('No direct script access.');

class Session_Cookie extends Kohana_Session_Cookie {}
