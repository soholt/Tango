<?php defined('SYSPATH') OR die('No direct access allowed.');

interface Os
{
/*
	public function serviceActions($name);
	public function service($service, $action);
	public function stop($service);
	public function start($service);
	public function status($service);
	public function kill($service);
	public function pkgInstall($pkg);
	public function pkgSearch($pkg);
	public function read($file);
	public function write($file, $content);
	public function networking($data);
	public function defaultGateway($data);
*/
}//EOF