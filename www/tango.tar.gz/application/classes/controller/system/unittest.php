<?php defined('SYSPATH') or die('No direct script access.');

class Controller_System_Unittest extends Base
{

	public function action_index()
	{
		$this->render('unit test');

	}

}//EOF