<?php defined('SYSPATH') or die('No direct script access.');

class Controller_System_Crond extends Base
{
	public function action_index()
	{
		$this->render('TODO ' . __METHOD__);
	}

}//EOF