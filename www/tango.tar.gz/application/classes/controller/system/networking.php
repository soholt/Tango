<?php defined('SYSPATH') or die('No direct script access.');

/**
 *
 * Enter description here ...
 * @author gin
 * TODO HARDWARE bonding, interfaces, up/down, config
 * TODO other network computers(+shared resources), hosts,resovl,default gw
 */
class Controller_System_Networking extends Base
{
	//http://www.linuxhorizon.ro/bonding.html

	public function action_index()
	{
		$this->render('TODO ' . __METHOD__);
	}

	public function action_a()
	{

	}

}//EOF