<?php
/*
install base tools like mbuffer, bonnie, iperf and netcat