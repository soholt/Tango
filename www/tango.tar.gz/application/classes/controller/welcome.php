<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Welcome extends Controller_Template
{

	//	TODO clear all caches maybe

	//	TODO after login forward to referrer
	//	TODO twitter rss feed on front page, donate button
	//	TODO show google ad maybe
	//	TODO packaging routine eg: clear config/users

	public function action_index()
	{

		if(is_null(Tango::detectOs()))
		{
			//donate and request support for your os
			//change config if you know its supported
			$view = __METHOD__;
			$this->template->content = $view;
		}
		else
		{
			//cool
			$view = View::factory('welcome/login');
			$this->template->content = $view;
		}

	}

	public function action_login()
	{

		$data = $this->request->query();

		$username = $this->request->query('username');

		if( ! is_null($username) )
		{

			$user = Kohana::$config->load('users/' . $username);

			Fire::warn('usename ' . $user);

		}

		Fire::warn($data);


		$view = __METHOD__;
		$this->template->content = $view;
	}

	public function action_register()
	{
Tango::DetectOs();
		$users = Tango::users();

		if(count($users) > 0)
		{

			print_r($users);
			//	for sec reasons cant create any more users
			// if you forgot your password, delete /config/users/YOUR_USERNAME.php (temporary remove other users files)

			$view = __METHOD__;
			$this->template->content = $view;
		}
		else
		{

			//	if theres a request with username/password,
			//	crete new user, redirect on success
			//	else
			//	show registration form

			$view = __METHOD__;
			$this->template->content = $view;

		}

	}

	public function action_controllers()
	{
		$this->auto_render = FALSE;

		$directory = $this->request->param('id');

	exec('ls ' . APPPATH . 'classes/controller/' . $directory, $_subMenu);

	$controllers = '';

			foreach ($_subMenu as $__subMenu)
			{
				if(!is_array($__subMenu) && $__subMenu != 'index.php')
				{
					$__subMenu = substr($__subMenu, 0, -4);
					//$menu[$__subMenu] = $__subMenu;
					$controllers .= '|<a href="#" onclick="ax(\'/' . $directory . '/' . $__subMenu . '/methods\',\'methods\')"> ' . $__subMenu . ' </a>|';

				}
			}

		echo $controllers;

	}


/*
$this->request->directory() . '/' . $this->request->controller() . '/' . $this->request->action()

// From within a controller:
$this->request->param('key_name');

// Can be used anywhere:
Request::current()->directory();
Request::current()->controller();
Request::current()->action();


*/

}//EOF