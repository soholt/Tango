<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Storage_Index extends Base
{

	public function action_index()
	{

		//TODO in view file, if string, echo unavailable for your system
		$data['dev'] = $this->os->storageDevs();
		$data['info'] = $this->os->storageDevInfo('/dev/sda');
		$data['raid'] = $this->os->storageRaid();
		$this->render($data);
	}

	public function action_hardware()
	{
		$this->render($this->os->storageDevs(), 'storage/index/hardware');
	}

}//EOF