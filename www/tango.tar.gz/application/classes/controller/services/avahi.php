<?php defined('SYSPATH') or die('No direct script access.');

//http://www.zaphu.com/2008/04/29/ubuntu-guide-configure-avahi-to-broadcast-services-via-bonjour-to-mac-os-x/
//http://www.kremalicious.com/2008/06/ubuntu-as-mac-file-server-and-time-machine-volume/

class Controller_Services_Avahi extends Base
{

	public function before()
	{

		parent::before();

		//$this->render();

	}

	public function action_index()
	{

		$cpu = $this->exec('cat /proc/cpuinfo');

		$this->render($cpu);



		//$this->render();

	}

	public function action_install()
	{
		if(isset($_REQUEST['install']))
		{
			$cmd[] = $this->os->pkgInstall('cpufrequtils powernowd', 1);
			$cmd[] = 'cat /proc/cpuinfo';
			$this->sh($cmd);
			//echo $cmd;
		}
	}
}//EOF
