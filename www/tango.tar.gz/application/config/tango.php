<?php defined('SYSPATH') OR die('No direct access allowed.');

$data['os'] = 'auto';

$data['cache'] = FALSE;
//$data['cacheTtl'] = 0;	//	in seconds; 0 - no cache
//$data['sessionTtl'] = 60 * 60 * 2;	//	in seconds; 0 - never expire

return $data;