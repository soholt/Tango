
<a href="http://zfsonlinux.org/spl-regression-suite.html">http://zfsonlinux.org/spl-regression-suite.html</a>

<input type="button" value="splat -a" onclick="sh('splat','-a')" />
<input type="button" value="splat -v" onclick="sh('splat','-v')" />

<div id="sh"></div>
<div id="status"></div>

