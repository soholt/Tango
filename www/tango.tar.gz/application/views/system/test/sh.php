sh
<input type="button" value="apt-get update" onclick="sh('apt-get','update')" />

<input type="button" value="apt-get upgrade" onclick="sh('apt-get','upgrade')" />
<input type="button" value="apt-get dist-upgrade" onclick="sh('apt-get','dist-upgrade')" />
<input type="button" value="test" onclick="sh('test')" />
<div id="sh"></div>
<div id="status"></div>