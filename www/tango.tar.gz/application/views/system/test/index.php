<input type="button" value="test sh" onclick="shhh('/system/test/sh')" />

