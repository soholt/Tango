<?php

if(isset($data))
{
	if(is_array($data) && count($data) > 0)
	{
		echo '<pre>';
		print_r($data);
		echo '</pre>';
	}
	else
	{
		echo $data;
	}
}