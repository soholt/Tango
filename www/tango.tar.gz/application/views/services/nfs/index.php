<?php ?>

<input type="button" value="config" onclick="ax('/services/nfs/config', 'shStatus')" />

<div id="shStatus"></div>
<div id="shOutput"></div>

<input id="shOutput" type="textarea" name="config" />