<input type="button" value="<?php echo __('install'); ?>" onclick="shhh('/services/nfs/service/install')" />
<div id="shStatus"></div>
<div id="shOutput"></div>